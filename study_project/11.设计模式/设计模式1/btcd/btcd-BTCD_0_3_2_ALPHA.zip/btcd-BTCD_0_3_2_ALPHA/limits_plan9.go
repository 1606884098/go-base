// Copyright (c) 2013 Conformal Systems LLC.
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package main

// Plan 9 has no process accounting. no-op here
func setLimits() error {
	return nil
}
